"""Offline straightness measurement, original pixels; no source images modified."""
from pathlib import Path
import hashlib
import json
import csv
import cv2
import numpy as np
from scipy.signal import find_peaks
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

OUT=Path(__file__).resolve().parent
SOURCES=[
    dict(file='photo_20261102_182221_237343.png', mode='普通矫正',time='18:22:21',bounds=(435,935,200,491)),
    dict(file='photo_20261102_182228_554589.png', mode='原图',time='18:22:28',bounds=(440,950,205,535))]


def read(path):
    image=cv2.imdecode(np.frombuffer(path.read_bytes(),np.uint8),cv2.IMREAD_COLOR)
    assert image.shape==(720,1280,3)
    return image


def tls(points):
    center=points.mean(0)
    offsets=points-center
    _,eigenvectors=np.linalg.eigh(offsets.T@offsets)
    normal=eigenvectors[:,0]
    residual=offsets@normal
    return dict(point_count=len(points),rms_px=float(np.sqrt(np.mean(residual**2))),
        p95_abs_px=float(np.percentile(np.abs(residual),95)),max_abs_px=float(np.max(np.abs(residual))),
        center=center.tolist(),normal=normal.tolist()),residual


def trace(response,seed,axis,limits,anchor,radius=3):
    def locate(along,expected,search=5):
        values=response[along,:] if axis=='vertical' else response[:,along]
        low,high=int(round(expected))-search,int(round(expected))+search+1
        band=values[low:high]
        baseline=float(np.percentile(band,30))
        peak=low+int(np.argmax(band))
        if values[peak]-baseline<20:return None
        coords=np.arange(peak-radius,peak+radius+1)
        weights=np.maximum(0,values[coords]-baseline)
        if not weights.sum():return None
        center=float(coords@weights/weights.sum())
        return center if abs(center-expected)<=search else None
    initial=locate(anchor,seed,7)
    if initial is None:initial=float(seed)
    found={}
    for positions in (range(anchor,limits[1]),range(anchor-1,limits[0]-1,-1)):
        previous=initial
        for along in positions:
            center=locate(along,previous)
            if center is not None:
                previous=center
                found[along]=[center,along] if axis=='vertical' else [along,center]
    return np.array([found[key] for key in sorted(found)],float)


def curve(points,axis,limits):
    j=1 if axis=='vertical' else 0
    x,y=points[:,j],points[:,1-j]
    keep=(x>=limits[0])&(x<=limits[1])
    for _ in range(5):
        model=np.polynomial.Polynomial.fit(x[keep],y[keep],3)
        residual=y-model(x)
        scale=max(.4,1.4826*np.median(np.abs(residual[keep]-np.median(residual[keep]))))
        keep=(np.abs(residual)<4*scale)&(x>=limits[0])&(x<=limits[1])
    return model


def analyze(image,bounds,radius=3,crossing_margin=5):
    gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
    v=cv2.morphologyEx(gray,cv2.MORPH_BLACKHAT,np.ones((1,11),np.uint8)).astype(float)
    h=cv2.morphologyEx(gray,cv2.MORPH_BLACKHAT,np.ones((11,1),np.uint8)).astype(float)
    x0,x1,y0,y1=bounds
    vs=find_peaks(v[325:355,x0:x1].mean(0),distance=12,prominence=9,height=18)[0]+x0
    hs=find_peaks(h[y0:y1,640:740].mean(1),distance=12,prominence=9,height=18)[0]+y0
    if (len(vs),len(hs))!=(25,15):raise ValueError(f'Grid detection: {len(vs)}V / {len(hs)}H')
    # The chart is smaller than the previous pair. Seed locations and chart
    # bounds are adapted; intensity localization and final TLS settings are kept.
    # Use the central 60% for horizontal guidance in BOTH images: the raw
    # top line's initial tracker follows a vertical intersection near x846.
    # Final measured samples still cover the full chart line, not this support.
    vtrim=.15*(y1-y0);htrim=.20*(x1-x0)
    vm=[curve(trace(v,s,'vertical',(y0,y1),355),'vertical',(y0+vtrim,y1-vtrim)) for s in vs]
    hm=[curve(trace(h,s,'horizontal',(x0,x1),670),'horizontal',(x0+htrim,x1-htrim)) for s in hs]
    records=[]
    for axis,response,models,others,limits in [('vertical',v,vm,hm,(y0,y1)),('horizontal',h,hm,vm,(x0,x1))]:
        j=1 if axis=='vertical' else 0
        for index,model in enumerate(models):
            found=[]
            for along in range(*limits):
                predicted=float(model(along))
                crosses=np.array([other(predicted) for other in others])
                if not crosses[0]+8<along<crosses[-1]-8:continue
                if np.min(np.abs(crosses-along))<=crossing_margin:continue
                values=response[along,:] if axis=='vertical' else response[:,along]
                low,high=int(round(predicted))-5,int(round(predicted))+6
                band=values[low:high]
                baseline=float(np.percentile(band,30))
                peak=low+int(np.argmax(band))
                if values[peak]-baseline<20:continue
                coords=np.arange(peak-radius,peak+radius+1)
                weights=np.maximum(0,values[coords]-baseline)
                if not weights.sum():continue
                center=float(coords@weights/weights.sum())
                if abs(center-predicted)>5:continue
                crosses=np.array([other(center) for other in others])
                if np.min(np.abs(crosses-along))<=crossing_margin:continue
                found.append([center,along] if axis=='vertical' else [along,center])
            points=np.array(found,float)
            if len(points)<40:raise ValueError(f'Insufficient samples {axis} {index}: {len(points)}')
            fit,residual=tls(points)
            gaps=np.diff(points[:,j]);jumps=np.abs(np.diff(points[:,1-j]))
            fit.update(label=('V' if axis=='vertical' else 'H')+f'{index+1:02d}',axis=axis,
                span_px=float(np.ptp(points[:,j])),
                max_distance_to_guidance_px=float(np.max(np.abs(points[:,1-j]-model(points[:,j])))),
                adjacent_jumps_over_1_5px=int(np.sum((gaps<=2)&(jumps>1.5))))
            records.append((fit,points,residual))
    return records


def summary(records):
    residual=np.concatenate([r[2] for r in records])
    return dict(line_count=len(records),point_count=len(residual),
        rms_px=float(np.sqrt(np.mean(residual**2))),p95_abs_px=float(np.percentile(np.abs(residual),95)),
        max_abs_px=float(np.max(np.abs(residual))),worst_line_rms_px=max(r[0]['rms_px'] for r in records),
        median_line_rms_px=float(np.median([r[0]['rms_px'] for r in records])),
        min_points_per_line=min(r[0]['point_count'] for r in records),
        max_distance_to_guidance_px=max(r[0]['max_distance_to_guidance_px'] for r in records),
        adjacent_jumps_over_1_5px=sum(r[0]['adjacent_jumps_over_1_5px'] for r in records))


def csv_write(path,header,rows):
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.writer(f);writer.writerow(header);writer.writerows(rows)


def main():
    all_records=[];reports=[];images=[]
    for source in SOURCES:
        path=OUT/'inputs'/source['file'];image=read(path);images.append(image)
        records=analyze(image,source['bounds']);all_records.append(records)
        report=dict(source=source,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
            size=[1280,720],detail_enhancement=False,
            mode_evidence='User confirmed 18:22:21 ordinary correction; 18:22:28 raw; detail enhancement off for both.',
            all_lines=summary(records),vertical=summary([r for r in records if r[0]['axis']=='vertical']),
            horizontal=summary([r for r in records if r[0]['axis']=='horizontal']),
            sensitivity={
                'centroid_radius_2':summary(analyze(image,source['bounds'],radius=2)),
                'crossing_margin_7':summary(analyze(image,source['bounds'],crossing_margin=7))},
            lines=[r[0] for r in records])
        reports.append(report)
        stem=Path(source['file']).stem
        csv_write(OUT/(stem+'_lines.csv'),['line','axis','point_count','span_px','rms_px','p95_abs_px','max_abs_px'],
            [[fit[k] for k in ('label','axis','point_count','span_px','rms_px','p95_abs_px','max_abs_px')] for fit,_,_ in records])
        csv_write(OUT/(stem+'_points.csv'),['line','x_px','y_px','perpendicular_residual_px'],
            [[fit['label'],x,y,r] for fit,points,residuals in records for (x,y),r in zip(points,residuals)])
        print(source['time'],source['mode'],json.dumps(report['all_lines']),flush=True)
    reduction=100*(1-reports[0]['all_lines']['rms_px']/reports[1]['all_lines']['rms_px'])
    result=dict(images=reports,rms_reduction_percent=reduction,method=dict(
        grid='25 vertical + 15 horizontal lines; original pixel coordinates, no image rescaling.',
        localization='11px cross-axis blackhat; +/-5px search; centroid radius3; contrast >=20/255; robust cubic guidance for association only.',
        masking='Exclude intersections +/-5px using opposite-family cubic guidance; 8px endpoint margin.',
        fitting='Orthogonal TLS of measured intensity centroids; no final straight-line residual outlier rejection. Pooled RMS uses all retained points.',
        adaptations='Chart ROI, seed bands, peak separation12px, seed anchors and proportional central guidance support updated for smaller new chart. Horizontal guidance uses central60% in both images to avoid initial raw H01 crossing drift at x846. Final measured points cover full line; main localization parameters unchanged.',
        limitation='Pixel image residual includes paper/printing/optics/correction/sampling/localization; not physical mm accuracy or FPGA-only error. Different chart scale from previous pair.'))
    (OUT/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    font_manager.fontManager.addfont('C:/Windows/Fonts/msyh.ttc')
    plt.rcParams.update({'font.family':'Microsoft YaHei','axes.unicode_minus':False})
    fig,axes=plt.subplots(2,2,figsize=(13,9))
    for ax,source,image,records,report in zip(axes[0],SOURCES,images,all_records,reports):
        ax.imshow(cv2.cvtColor(image,cv2.COLOR_BGR2RGB))
        for fit,points,_ in records:
            ax.scatter(points[::3,0],points[::3,1],s=3,c='#00e5ff' if fit['axis']=='vertical' else '#ff38bd')
        ax.set(xlim=(425,960),ylim=(550,190),title=f'{source["time"]} {source["mode"]}｜RMS {report["all_lines"]["rms_px"]:.3f} 像素',xlabel='原图 x / 像素',ylabel='原图 y / 像素')
    ax=axes[1,0];p=np.arange(40)
    for i,(records,source) in enumerate(zip(all_records,SOURCES)):
        ax.bar(p+(-.2 if i==0 else .2),[r[0]['rms_px'] for r in records],.4,label=source['mode'])
    ax.set_xticks(p);ax.set_xticklabels([r[0]['label'] for r in all_records[0]],rotation=90,fontsize=6)
    ax.set(title='每条网格线的正交残差 RMS（越小越好）',ylabel='像素');ax.legend();ax.grid(axis='y',alpha=.2)
    ax=axes[1,1]
    for source,records in zip(SOURCES,all_records):
        fit,points,residual=records[26]
        if residual[0]<0:residual=-residual
        ax.scatter(points[:,0],residual,s=5,label=source['mode'])
    ax.axhline(0,color='gray',linewidth=.7);ax.grid(alpha=.2);ax.legend()
    ax.set(title='第2条横线 H02 的残差',xlabel='原图 x / 像素',ylabel='到拟合直线的垂距 / 像素')
    fig.suptitle(f'最新两张网格图直线度｜细节增强关闭｜整体 RMS 降低 {reduction:.1f}%',fontsize=15)
    fig.tight_layout();fig.savefig(OUT/'straightness_comparison.png',dpi=130);plt.close(fig)
    print('RMS reduction percent',reduction,flush=True)


if __name__=='__main__':main()
