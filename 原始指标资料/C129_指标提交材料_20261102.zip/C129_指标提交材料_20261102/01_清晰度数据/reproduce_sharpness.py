"""Recompute all 40 stored candidate ROIs without altering the source results."""
from pathlib import Path
import json
import math
import hashlib
import numpy as np
from measure_quality_reference import load_gray_roi, analyze_edge

ROOT=Path(__file__).resolve().parent
stored=json.loads((ROOT/'results.json').read_text(encoding='utf-8'))
files={'1':'01_corrected_edges.png','2':'02_raw_edges.png'}
checks=[];summary={}
for number,filename in files.items():
    path=ROOT/'inputs'/filename
    expected_hash=stored['inputs'][int(number)-1]['sha256']
    assert hashlib.sha256(path.read_bytes()).hexdigest()==expected_hash
    calculated={}
    for row in stored['sharpness_roi_details'][number]:
        try:
            measurement,_=analyze_edge(load_gray_roi(path,row['roi_xywh'],'srgb'),row['axis'])
            actual=measurement['mtf50_cycles_per_pixel']
            expected=row.get('measurement',{}).get('mtf50_cycles_per_pixel')
            matched=row['status']=='accepted' and ((actual is None and expected is None) or
                (actual is not None and expected is not None and math.isclose(actual,expected,abs_tol=1e-8)))
            calculated[row['label']]=actual
            checks.append(dict(image=number,edge=row['label'],matched=matched,mtf50=actual))
        except ValueError as error:
            checks.append(dict(image=number,edge=row['label'],matched=row['status']=='rejected',rejected=str(error)))
    labels=stored['sharpness'][number]['common_edges']
    summary[number]=float(np.median([calculated[label] for label in labels]))
result={'all_roi_results_match':all(c['matched'] for c in checks),'checked_rois':len(checks),
    'common_edge_median_mtf50_cycles_per_pixel':summary,'checks':checks}
(ROOT/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},ensure_ascii=False,indent=2))
if not result['all_roi_results_match']:raise SystemExit('ROI verification mismatch')
